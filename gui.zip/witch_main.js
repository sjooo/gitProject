$(document).ready(function(){

	ih=$(".banner .center .blogo img").height();
	$(".banner .center .blogo img").css("width",ih*1.43)

	yh=$(".banner .center .you iframe").height();
	$(".banner .center .you iframe").css("width",yh*1.8)
	
	yw=$(".banner .center .you iframe").width();
	$(".banner .center .you").css("width",yw)

	yh2=$(".section .center .you2 iframe").width();
	$(".section .center .you2 iframe").css("height",yh2*0.56)
	
	/*yw2=$(".section .center .you2 iframe").width();
	$(".section .center .you2").css("width",yw2)*/



	$(window).resize(function(){
		ih=$(".banner .center .blogo img").height();
		$(".banner .center .blogo img").css("width",ih*1.43)


		yh=$(".banner .center .you iframe").height();
		$(".banner .center .you iframe").css("width",yh*1.8)

		yw=$(".banner .center .you iframe").width();
		$(".banner .center .you").css("width",yw)

		
		yh2=$(".section .center .you2 iframe").width();
		$(".section .center .you2 iframe").css("height",yh2*0.56)
	
		/*yw2=$(".section .center .you2 iframe").width();
		$(".section .center .you2").css("width",yw2)*/

		console.log(yh2)
		
	});
	
	$(".section .center .pbox #pe1").css("display","block");
	$(".section .center .pagination a").click(function(){
		pa=$(this).attr("data-li");
		console.log(pa);
		$("#pe"+pa).css("display","block");
		$("#pe"+pa).siblings().css("display","none");
		$(this).addClass("active").siblings().removeClass("active");
	});/*click*/

	

});//doc

/*login*/
	// Get the modal
	var modal = document.getElementById('id01');

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
	}