$(document).ready(function(){
	wh=$(window).height();
	ww=$(window).width();

	mh=$(".mySlides img").height();
	mw=$(".mySlides img").width();

	$(".mobox").css("height",wh);
	
	/*$(".slideshow-container").css({"margin-top":-mh/2});
	$(".slideshow-container").css({"margin-left":-mw/2});*/

	

	

	$(window).on("load resize",function(){
		wh=$(window).height();
		ww=$(window).width();
		

		$(".mobox").css("height",wh);
	
		

	

	/*$(".slideshow-container").css({"margin-top":-mh/2});
	$(".slideshow-container").css({"margin-left":-mw/2});*/
	});//resize
	
	
	$(".column img").click(function(){
		$(".mobox ,.slideshow-container,.ex").css("display","block");
		$('html').css("overflow", "hidden"); 
		

	});

	$("i").click(function(){
		$(".mobox ,.slideshow-container, .ex").css("display","none");
		$('html').css("overflow", "auto");
		});
	
	
});//doc

/*slide*/
	var slideIndex = 1;
	showSlides(slideIndex);

	function plusSlides(n) {
	  showSlides(slideIndex += n);
	}

	function currentSlide(n) {
	  showSlides(slideIndex = n);
	}

	function showSlides(n) {
	  var i;
	  var slides = document.getElementsByClassName("mySlides");
	  if (n > slides.length) {slideIndex = 1}    
	  if (n < 1) {slideIndex = slides.length}
	  for (i = 0; i < slides.length; i++) {
		  slides[i].style.display = "none";  
	  }
	  slides[slideIndex-1].style.display = "block";  
	 
	}
	
