$(document).ready(function(){

/*drop*/

	$(".sidenav .drop").hide();

	$(".sidenav .menu li:nth-child(2)").mouseover(function(){
		$(".sidenav .drop").show();
	}).mouseleave(function(){
		$(".sidenav .drop").hide();
	});

/*i*/
	$(".tbt .fa").html("<i class='fa fa-bars'></i>");
	
	$(".tbt").click(function(){
	
	
		if($(".sidenav").css("display")=="none")
		{
			$(this).find(".fa").html("<i class='fa fa-close'></i>");
			$(".sidenav").show();
			
			
		} else {
			
			$(this).find(".fa").html("<i class='fa fa-bars'></i>");
			$(".sidenav").hide();
			
		}
	});




});//doc


/*copy*/
	$('.urlCopyBtn').click(function(){	

		var urlAddress= $('#urlAddress');

		urlAddress.css('display','block').select();

		document.execCommand("Copy");

		urlAddress.css('display','none');

		alert('URL 주소가 복사 되었습니다');	

		return false;

	});

/*tob_bt*/
	window.onscroll = function() {scrollFunction()};

	function scrollFunction() {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
			document.getElementById("myBtn").style.display = "block";
		} else {
			document.getElementById("myBtn").style.display = "none";
		}
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	}

