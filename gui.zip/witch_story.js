$(document).ready(function(){
	wh=$(window).height();
	ww=$(window).width();

	console.log(wh,ww)
	
	$(".section .sec_box").css("min-height",wh)


	$(window).resize(function(){
		wh=$(window).height();
		ww=$(window).width();

		console.log(wh,ww)
	
		$(".section .sec_box").css("min-height",wh)
	});/*resize*/

	/*$(".section .sec_box .openbt li:last-child").css("display","none");
	$(".section .sec_box .openbt li").click(function(){
		$(this).css("display","none");
		$(this).siblings().css("display","block");
	
	});

	$(".section .sec_box .openbt li").click(function(){
		if ($(".section .sec_bottom").css("display")=="none")
		{
			$(".section .sec_bottom").css("display","block")
		} else {
			$(".section .sec_bottom").css("display","none")
		}
	});*/

});




