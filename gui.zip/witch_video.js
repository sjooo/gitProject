$(document).ready(function(){
	wh=$(window).height();
	ww=$(window).width();
	vh=wh-294
	

	iw=ww*0.7	

	/*console.log(iw)*/
	
	$(".section .sec_vi").css("min-height",wh)
	/*$(".section .sec_vi .vicbox").css("width","100%")
	$(".section .sec_vi .vicbox").css("height",vw*1.333)
	$(".section .sec_vi .vicbox .svibox").css("width",vh/2)*/

	$(".black").css({"width":ww, "height":wh})
	
	$(".black .blackv").css({"height":iw*0.56, "margin-top":-iw*0.56*0.5, "margin-left":-iw/2})
	


	$(window).on("load resize",function(){
		wh=$(window).height();
		ww=$(window).width();
		vh=wh-294
		
		iw=ww*0.7	

	
		$(".section .sec_vi").css("min-height",wh)
		/*$(".section .sec_vi .vicbox").css("width",vh*1.5)
		$(".section .sec_vi .vicbox").css("height",vh)
		$(".section .sec_vi .vicbox .svibox").css("width",vh/2)*/

		$(".black").css({"width":ww, "height":wh})

		$(".black .blackv").css({"height":iw*0.56, "margin-top":-iw*0.56*0.5, "margin-left":-iw/2})
	});/*resize*/
	
	
	
	$(".section .sec_vi .vicbox .svibox").click(function(){
		dl=$(this).attr("data-li");
		$(".black .blackv iframe").attr("src",dl)
		
		
		$(".black").css("display","block")
		$(".black .blackv iframe").css("display","block")
	});
	
	$(".black .blackv .fa").click(function(){
		
		$(".black").css("display","none")
		/*dl=$(this).siblings().attr("src");

		console.log(dl)*/
		$(this).siblings().attr("src","images/b.png")
		
	});



	
	
});




