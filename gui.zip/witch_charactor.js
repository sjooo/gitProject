$(document).ready(function(){
	wh=$(window).height();
	ww=$(window).width();

	
	
	$(".section").css("min-height",wh)


	$(window).resize(function(){
		wh=$(window).height();
		ww=$(window).width();

		
	
		$(".section").css("min-height",wh)

	});

	$(".section .chabox .menu li").mouseover(function(){
		if (ww>769)
			{
				$(this).prepend("<div class='semo'></div>")
			}
		
		console.log(ww)
	}).mouseleave(function(){
			
		$(".semo").remove()
	});

	
	$(".cha_left:not(#cl1)").animate({"opacity":"0"});
	$(".cha_left:first-child").css("display","block")
	$(".cha_left:first-child").animate({"opacity":"1"});
	
	$(".section .chabox .menu li").click(function(){
		cln=$(this).attr("data-li");
		
		$("#cl"+cln).animate({"opacity":"1"});
		$("#cl"+cln).css("display","block");
		
		$("#cl"+cln).siblings().animate({"opacity":"0"});
		$("#cl"+cln).siblings().css({"display":"none"});
		
		$(this).addClass("active")
		$(this).prepend("<div class='semo2'></div>")
		$(this).siblings().removeClass("active")
		$(this).siblings().find(".semo2").remove();
		
	});

	




	/*chrh=$(".section .chabox .cha_content .cha_left").height()


		$(".section .chabox .cha_content .cha_right").css("height",chrh)*/
});
