 /*fan_pc*/

    


$(document).ready(function(){
	wh=$(window).height();
	ww=$(window).width();
	console.log(wh)
	$(".section .page").css("height",wh)
	
	console.log(ww,wh);

	


	th=$(".section .fpay .pleft .pleft_t").height()
	lh=$(".section .fpay .pleft").height()
	$(".section .fpay .pleft .pleft_b").css("height",lh-th)

	/*console.log(th,lh)*/

	
	
	$(".menubt .fa").html("<i class='fa fa-bars'></i>");
	
	$(".menubt").click(function(){
	
	
		if($(".header .center .menu").css("display")=="none")
		{
			$(".menubt .fa").html("<i class='fa fa-close'></i>");
			$(".header .center .menu").show();
			
			
		} else {
			
			$(".menubt .fa").html("<i class='fa fa-bars'></i>");
			$(".header .center .menu").hide();
			
		}
	});


	
	
	
	$(window).on("load resize",function(){
	

	wh=$(window).height();
	ww=$(window).width();
	console.log(wh)
	
	
	$(".section .page").css("height",wh)

	
	
	th=$(".section .fpay .pleft .pleft_t").height();
	lh=$(".section .fpay .pleft").height();
	$(".section .fpay .pleft .pleft_b").css("height",lh-th);

	
	
	
	
	
	
	docpos=new Array(0,1*wh,2*wh,3*wh,4*wh);
	
	console.log(docpos)

/* menu click*/
	
		$(".header .center .menu li").on("click",function(e){
				idx=$(".header .center .menu li").index($(this));

			
			$(this).find("a").addClass("active").siblings().removeClass("active");
			$("html, body").animate({scrollTop:docpos[idx]});
			e.preventDefault();
			});// click

/*tpmenu click*/
		$(".header .center .tpmenu li").on("click",function(e){
				idx=$(".header .center .tpmenu li").index($(this));

			
			$(this).addClass("active").siblings().removeClass("active");
			$("html, body").animate({scrollTop:docpos[idx]});
			e.preventDefault();
			});// click


/*pagebt click*/
		$(".pagebt li").on("click",function(e){
			idx=$(".pagebt li").index($(this));

		console.log(idx);
		$(this).parent().addClass("active").siblings().removeClass("active");
		$("html, body").animate({scrollTop:docpos[idx]});
		e.preventDefault();
		});// click


/*basic*/
		if (ww>768)
		{
			
			$(".section .fpay .pleft .pleft_t .con li:first-child h3").css({"opacity":"0"})
			$(".section .fpay .pleft .pleft_t .con li:nth-child(2) h3").css({"opacity":"0"})
			$(".section .fpay .pleft .pleft_t .con li .fa").css({"opacity":"0"})

			$(".section .fclub .center img").css({"top":"450px"})
			$(".section .fmy").css({"background-position":"-1500px"})
		
		if ($(window).scrollTop()>=0)
				{
				
				
				$(".section .fhome .hcon .hcon2").fadeIn(1000);
				$(".section .fhome .hcon .hcon1").delay(500).fadeIn(800)
				$(".section .fhome .hcon .hcon3").delay(500).fadeIn(800);

				}
		};
		
		
		
		
		
		
		
		
/*>768*/
		
			$(window).scroll(function(){
				
					
					if ($(this).scrollTop() >=4*wh )
					{
						$(".header .center .menu li").eq(4).addClass("active").siblings().removeClass("active")
						$(".header .center .tpmenu li").eq(4).addClass("active").siblings().removeClass("active")
						$(".pagebt li").eq(4).addClass("active").siblings().removeClass("active")

					} else if ($(this).scrollTop() >=3*wh && $(this).scrollTop() < 4*wh)
					{
						$(".header .center .menu li").eq(3).addClass("active").siblings().removeClass("active")
						$(".header .center .tpmenu li").eq(3).addClass("active").siblings().removeClass("active")
						$(".pagebt li").eq(3).addClass("active").siblings().removeClass("active")
						
					}else if ($(this).scrollTop() >=2*wh && $(this).scrollTop() < 3*wh)
					{
						$(".header .center .menu li").eq(2).addClass("active").siblings().removeClass("active")
						$(".header .center .tpmenu li").eq(2).addClass("active").siblings().removeClass("active")
						$(".pagebt li").eq(2).addClass("active").siblings().removeClass("active")
						
					}else if ($(this).scrollTop() >=1*wh && $(this).scrollTop() < 2*wh)
					{
						$(".header .center .menu li").eq(1).addClass("active").siblings().removeClass("active")
						$(".header .center .tpmenu li").eq(1).addClass("active").siblings().removeClass("active")
						$(".pagebt li").eq(1).addClass("active").siblings().removeClass("active")
						
					}	else {
						
						$(".header .center .menu li").eq(0).addClass("active").siblings().removeClass("active")
						$(".pagebt li").eq(0).addClass("active").siblings().removeClass("active")
						
					};

				
				});//window scroll

				$(window).scroll(function(){
				
					if (ww>768)
					{
								if ($(this).scrollTop() >=4*wh )
							{
								$(".section .fmoney").animate({"background-color": '#ccc'})
								$(".section .fmoney").colorAnimation({ color: '#001743', property: 'background-color', duration: 1500 });
								$(".section .fmoney .sm .smo").delay(1000).fadeIn(1500);
								
								
							} else if ($(this).scrollTop() >=3*wh && $(this).scrollTop() < 4*wh)
							{
								$(".section .fmy").animate({"background-position":"0"},1000)
								
							}else if ($(this).scrollTop() >=2*wh && $(this).scrollTop() < 3*wh)
							{
								$(".section .fclub .center img").animate({"top":"0px"},800)
							}else if ($(this).scrollTop() >=1*wh && $(this).scrollTop() < 2*wh)
							{
								$(".section .fpay .pleft .pleft_t .con li:first-child h3 ,.section .fpay .pleft .pleft_t .con li .fa ,.section .fpay .pleft .pleft_t .con li:nth-child(2) h3").animate({"opacity":"1"},1000)
							
								
							};

							}//if
						
						});//window scroll
					
					
					
				
			
			
			
			

			
			if (ww<=768)
			{
				$(window).scroll(function(){
				if ($(this).scrollTop() >=64)
				{
					$(".header .center .tpmenu").css("display","block")
				}else {
					$(".header .center .tpmenu").css("display","none")
				}

			});		
			}//if

			
			

			
	});//resize
});